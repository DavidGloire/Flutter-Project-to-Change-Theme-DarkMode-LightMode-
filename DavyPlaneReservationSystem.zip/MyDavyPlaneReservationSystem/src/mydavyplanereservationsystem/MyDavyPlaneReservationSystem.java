/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mydavyplanereservationsystem;

/**
 *
 * @author DAVID GLORY
 */
public class MyDavyPlaneReservationSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Splashz splash=new Splashz();
        splash.setVisible(true);
        
        try{
            
            
            for(int i=0;i<=100;i++){
                Thread.sleep(50);
                Splashz.jLabel4.setText(""+i+"%");
                Splashz.jProgressBar1.setValue(i);
                
                if(i==100){
                    login log=new login();
                    splash.setVisible(false);
                    log.setVisible(true);
                }
            }
    }
        catch(Exception e){
            
        }
    }
    
}
